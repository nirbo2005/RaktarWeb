export class Stock {}
