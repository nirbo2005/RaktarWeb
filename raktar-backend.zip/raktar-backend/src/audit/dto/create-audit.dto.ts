export class CreateAuditDto {}
